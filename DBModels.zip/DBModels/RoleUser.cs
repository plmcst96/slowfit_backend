﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;

namespace slowfit.DBModels;

public partial class RoleUser :  IdentityRole<int>
{
    public string? TenantId { get; set; }

    public int RoleId { get; set; }

    public string RoleName { get; set; } = null!;

    public virtual ICollection<User> Users { get; set; } = [];
}
