﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace slowfit.DBModels;

public partial class SlowFitContext : DbContext
{
    public SlowFitContext()
    {
    }

    public SlowFitContext(DbContextOptions<SlowFitContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Answer> Answers { get; set; }

    public virtual DbSet<Appointment> Appointments { get; set; }

    public virtual DbSet<Billing> Billings { get; set; }

    public virtual DbSet<BodyPart> BodyParts { get; set; }

    public virtual DbSet<CategoryOfDay> CategoryOfDays { get; set; }

    public virtual DbSet<DetailExercise> DetailExercises { get; set; }

    public virtual DbSet<Exercise> Exercises { get; set; }

    public virtual DbSet<Ingredient> Ingredients { get; set; }

    public virtual DbSet<InputType> InputTypes { get; set; }

    public virtual DbSet<LevelTraining> LevelTrainings { get; set; }

    public virtual DbSet<LocationTraining> LocationTrainings { get; set; }

    public virtual DbSet<Meal> Meals { get; set; }

    public virtual DbSet<MealIngredient> MealIngredients { get; set; }

    public virtual DbSet<Measure> Measures { get; set; }

    public virtual DbSet<Nutrition> Nutritions { get; set; }

    public virtual DbSet<NutritionMeal> NutritionMeals { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<PaymentType> PaymentTypes { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Question> Questions { get; set; }

    public virtual DbSet<Quiz> Quizzes { get; set; }

    public virtual DbSet<ResponseQuiz> ResponseQuizzes { get; set; }

    public virtual DbSet<RoleUser> RoleUsers { get; set; }

    public virtual DbSet<Training> Training { get; set; }

    public virtual DbSet<TypeNutrition> TypeNutritions { get; set; }

    public virtual DbSet<TypePlan> TypePlans { get; set; }

    public virtual DbSet<TypeTrainig> TypeTrainigs { get; set; }

    public virtual DbSet<User> Users { get; set; }

    public class ApplicationUser : IdentityUser<int>
    {
        public string? TenantId { get; set; }

        public string? FirstName { get; set; }

        public string? Surname { get; set; }

        public bool IsDeleted { get; set; } = false;

        public string Email { get; set; } = null!;

        public string Password { get; set; } = null!;

        public string? Address { get; set; }

        public string? City { get; set; }

        public string? Country { get; set; }

        public string? Province { get; set; }

        public int? ZipCode { get; set; }

        public int? RoleId { get; set; }

        public string? BirthDate { get; set; }

        public int? PtId { get; set; }

        public string? ImageProfile { get; set; }

        public string? Phone { get; set; }

        public virtual ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();

        public virtual ICollection<Billing> Billings { get; set; } = new List<Billing>();

        public virtual ICollection<Measure> Measures { get; set; } = new List<Measure>();

        public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

        public virtual ICollection<ResponseQuiz> ResponseQuizzes { get; set; } = new List<ResponseQuiz>();

        public virtual ICollection<Nutrition> Nutritions { get; set; } = new List<Nutrition>();

        public virtual RoleUser? Role { get; set; }
    }

    public class ApplicationRole : IdentityRole<int>
    {
        public string? TenantId { get; set; }

        public int RoleId { get; set; }

        public string RoleName { get; set; } = null!;

    }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ApplicationRole>().ToTable("AspNetRoles");

        modelBuilder.Entity<ApplicationUser>().ToTable("AspNetUsers");

        modelBuilder.Entity<IdentityUserRole<int>>().ToTable("AspNetUserRoles");

        modelBuilder.Entity<IdentityUserClaim<int>>().ToTable("AspNetUserClaims");

        modelBuilder.Entity<IdentityUserLogin<int>>().ToTable("AspNetUserLogins");

        modelBuilder.Entity<IdentityUserToken<int>>().ToTable("AspNetUserTokens");

        modelBuilder.Entity<IdentityRoleClaim<int>>().ToTable("AspNetRoleClaims");

        modelBuilder.Entity<Answer>(entity =>
        {
            entity.ToTable("answer");

            entity.HasIndex(e => e.QuestionId, "IX_answer_questionId");

            entity.Property(e => e.AnswerId).HasColumnName("answerId");
            entity.Property(e => e.AnswerString)
                .HasMaxLength(250)
                .IsUnicode(false)
                .HasColumnName("answerString");
            entity.Property(e => e.QuestionId).HasColumnName("questionId");

            entity.HasOne(d => d.Question).WithMany(p => p.Answers)
                .HasForeignKey(d => d.QuestionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_answer_question");
        });

        modelBuilder.Entity<Appointment>(entity =>
        {
            entity.ToTable("appointment");

            entity.HasIndex(e => e.UserId, "IX_appointment_userId");

            entity.Property(e => e.AppointmentId).HasColumnName("appointmentId");
            entity.Property(e => e.CallUrl)
                .HasMaxLength(350)
                .IsUnicode(false)
                .HasColumnName("callUrl");
            entity.Property(e => e.Date)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("date");
            entity.Property(e => e.Description)
                .HasMaxLength(250)
                .IsUnicode(false)
                .HasColumnName("description");
            entity.Property(e => e.Duration).HasColumnName("duration");
            entity.Property(e => e.PtId).HasColumnName("ptId");
            entity.Property(e => e.UserId).HasColumnName("userId");

            entity.HasOne(d => d.User).WithMany(p => p.Appointments)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_appointment_user");
        });

        //modelBuilder.Entity<AspNetRole>(entity =>
        //{
        //    entity.Property(e => e.Name).HasMaxLength(256);
        //    entity.Property(e => e.NormalizedName).HasMaxLength(256);
        //});

        //modelBuilder.Entity<AspNetRoleClaim>(entity =>
        //{
        //    entity.HasOne(d => d.Role).WithMany(p => p.AspNetRoleClaims).HasForeignKey(d => d.RoleId);
        //});

        //modelBuilder.Entity<AspNetUser>(entity =>
        //{
        //    entity.Property(e => e.CreatedTime).HasColumnName("Created_time");
        //    entity.Property(e => e.DeletedTime).HasColumnName("Deleted_time");
        //    entity.Property(e => e.Email).HasMaxLength(256);
        //    entity.Property(e => e.NormalizedEmail).HasMaxLength(256);
        //    entity.Property(e => e.NormalizedUserName).HasMaxLength(256);
        //    entity.Property(e => e.UpdatedTime).HasColumnName("Updated_time");
        //    entity.Property(e => e.UserName).HasMaxLength(256);

        //    entity.HasMany(d => d.Roles).WithMany(p => p.Users)
        //        .UsingEntity<Dictionary<string, object>>(
        //            "AspNetUserRole",
        //            r => r.HasOne<AspNetRole>().WithMany().HasForeignKey("RoleId"),
        //            l => l.HasOne<AspNetUser>().WithMany().HasForeignKey("UserId"),
        //            j =>
        //            {
        //                j.HasKey("UserId", "RoleId");
        //                j.ToTable("AspNetUserRoles");
        //            });
        //});

        //modelBuilder.Entity<AspNetUserClaim>(entity =>
        //{
        //    entity.HasOne(d => d.User).WithMany(p => p.AspNetUserClaims).HasForeignKey(d => d.UserId);
        //});

        //modelBuilder.Entity<AspNetUserLogin>(entity =>
        //{
        //    entity.HasKey(e => new { e.LoginProvider, e.ProviderKey });

        //    entity.HasOne(d => d.User).WithMany(p => p.AspNetUserLogins).HasForeignKey(d => d.UserId);
        //});

        //modelBuilder.Entity<AspNetUserToken>(entity =>
        //{
        //    entity.HasKey(e => new { e.UserId, e.LoginProvider, e.Name });

        //    entity.HasOne(d => d.User).WithMany(p => p.AspNetUserTokens).HasForeignKey(d => d.UserId);
        //});

        modelBuilder.Entity<Billing>(entity =>
        {
            entity.ToTable("billing");

            entity.HasIndex(e => e.OrderId, "IX_billing_orderId");

            entity.HasIndex(e => e.PaymentTypeId, "IX_billing_paymentTypeId");

            entity.HasIndex(e => e.UserId, "IX_billing_userId");

            entity.Property(e => e.BillingId).HasColumnName("billingId");
            entity.Property(e => e.Amount)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("amount");
            entity.Property(e => e.Date)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("date");
            entity.Property(e => e.OrderId).HasColumnName("orderId");
            entity.Property(e => e.PaymentTypeId).HasColumnName("paymentTypeId");
            entity.Property(e => e.UserId).HasColumnName("userId");

            entity.HasOne(d => d.Order).WithMany(p => p.Billings)
                .HasForeignKey(d => d.OrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_billing_order");

            entity.HasOne(d => d.PaymentType).WithMany(p => p.Billings)
                .HasForeignKey(d => d.PaymentTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_billing_paymentType");

            entity.HasOne(d => d.User).WithMany(p => p.Billings)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_billing_user");
        });

        modelBuilder.Entity<BodyPart>(entity =>
        {
            entity.ToTable("bodyPart");

            entity.Property(e => e.BodyPartId).HasColumnName("bodyPartId");
            entity.Property(e => e.BodyPartName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("bodyPartName");
        });

        modelBuilder.Entity<CategoryOfDay>(entity =>
        {
            entity.HasKey(e => e.CategoryId);

            entity.ToTable("categoryOfDay");

            entity.Property(e => e.CategoryId).HasColumnName("categoryId");
            entity.Property(e => e.MomentOfDay)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("momentOfDay");
        });

        modelBuilder.Entity<DetailExercise>(entity =>
        {
            entity.ToTable("detailExercise");

            entity.HasIndex(e => e.ExerciseId, "IX_detailExercise_exerciseId");

            entity.HasIndex(e => e.TrainingId, "IX_detailExercise_trainingId");

            entity.Property(e => e.DetailExerciseId).HasColumnName("detailExerciseId");
            entity.Property(e => e.ExerciseId).HasColumnName("exerciseId");
            entity.Property(e => e.NRipetition).HasColumnName("nRipetition");
            entity.Property(e => e.Pause).HasColumnName("pause");
            entity.Property(e => e.Phase)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("phase");
            entity.Property(e => e.Series).HasColumnName("series");
            entity.Property(e => e.TrainingId).HasColumnName("trainingId");

            entity.HasOne(d => d.Exercise).WithMany(p => p.DetailExercises)
                .HasForeignKey(d => d.ExerciseId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_detailExercise_exercise");

            entity.HasOne(d => d.Training).WithMany(p => p.DetailExercises)
                .HasForeignKey(d => d.TrainingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_detailExercise_training");
        });

        modelBuilder.Entity<Exercise>(entity =>
        {
            entity.ToTable("exercise");

            entity.HasIndex(e => e.LocationTrainingId, "IX_exercise_locationTrainingId");

            entity.Property(e => e.ExerciseId).HasColumnName("exerciseId");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("description");
            entity.Property(e => e.Image)
                .IsUnicode(false)
                .HasColumnName("image");
            entity.Property(e => e.LocationTrainingId).HasColumnName("locationTrainingId");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.TypeTrainingId).HasColumnName("typeTrainingId");
            entity.Property(e => e.UrlVideo)
                .IsUnicode(false)
                .HasColumnName("urlVideo");

            entity.HasOne(d => d.LocationTraining).WithMany(p => p.Exercises)
                .HasForeignKey(d => d.LocationTrainingId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_exercise_locationTraining");
        });

        modelBuilder.Entity<Ingredient>(entity =>
        {
            entity.ToTable("ingredient");

            entity.Property(e => e.IngredientId).HasColumnName("ingredientId");
            entity.Property(e => e.Calories).HasColumnName("calories");
            entity.Property(e => e.Carbohydrate)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("carbohydrate");
            entity.Property(e => e.Fats)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("fats");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Protein)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("protein");
        });

        modelBuilder.Entity<InputType>(entity =>
        {
            entity.ToTable("inputType");

            entity.Property(e => e.InputTypeId).HasColumnName("inputTypeId");
            entity.Property(e => e.InputTypeName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("inputTypeName");
        });

        modelBuilder.Entity<LevelTraining>(entity =>
        {
            entity.HasKey(e => e.LevelId);

            entity.ToTable("levelTraining");

            entity.Property(e => e.LevelId).HasColumnName("levelId");
            entity.Property(e => e.LevelString)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("levelString");
        });

        modelBuilder.Entity<LocationTraining>(entity =>
        {
            entity.HasKey(e => e.LocationId);

            entity.ToTable("locationTraining");

            entity.Property(e => e.LocationId).HasColumnName("locationId");
            entity.Property(e => e.LocationString)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("locationString");
        });

        modelBuilder.Entity<Meal>(entity =>
        {
            entity.ToTable("meal");

            entity.HasIndex(e => e.CategoryId, "IX_meal_categoryId");

            entity.Property(e => e.MealId).HasColumnName("mealId");
            entity.Property(e => e.Calories).HasColumnName("calories");
            entity.Property(e => e.Carbohydrate).HasColumnName("carbohydrate");
            entity.Property(e => e.CategoryId).HasColumnName("categoryId");
            entity.Property(e => e.Description)
                .HasMaxLength(150)
                .IsUnicode(false)
                .HasColumnName("description");
            entity.Property(e => e.Difficulty).HasColumnName("difficulty");
            entity.Property(e => e.Fats).HasColumnName("fats");
            entity.Property(e => e.ImageMeal)
                .IsUnicode(false)
                .HasColumnName("imageMeal");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.PreparingTime).HasColumnName("preparingTime");
            entity.Property(e => e.Protein).HasColumnName("protein");
            entity.Property(e => e.Recipe)
                .IsUnicode(false)
                .HasColumnName("recipe");

            entity.HasOne(d => d.Category).WithMany(p => p.Meals)
                .HasForeignKey(d => d.CategoryId)
                .HasConstraintName("FK_meal_categoryOfDay");
        });

        modelBuilder.Entity<MealIngredient>(entity =>
        {
            entity.HasKey(e => e.MealIngredientId).HasName("PK_Table_1");

            entity.ToTable("mealIngredient");

            entity.Property(e => e.MealIngredientId).HasColumnName("mealIngredientId");
            entity.Property(e => e.IngredientId).HasColumnName("ingredientId");
            entity.Property(e => e.MealId).HasColumnName("mealId");
            entity.Property(e => e.Quantity).HasColumnName("quantity");
            entity.Property(e => e.Unit)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("unit");

            entity.HasOne(d => d.Ingredient).WithMany(p => p.MealIngredients)
                .HasForeignKey(d => d.IngredientId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_mealIngredient_ingredient");

            entity.HasOne(d => d.Meal).WithMany(p => p.MealIngredients)
                .HasForeignKey(d => d.MealId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_mealIngredient_meal");
        });

        modelBuilder.Entity<Measure>(entity =>
        {
            entity.ToTable("measure");

            entity.HasIndex(e => e.BodyId, "IX_measure_bodyId");

            entity.HasIndex(e => e.UserId, "IX_measure_userId");

            entity.Property(e => e.MeasureId).HasColumnName("measureId");
            entity.Property(e => e.BodyId).HasColumnName("bodyId");
            entity.Property(e => e.Cm).HasColumnName("cm");
            entity.Property(e => e.CollectPeriod)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("collectPeriod");
            entity.Property(e => e.UserId).HasColumnName("userId");

            entity.HasOne(d => d.Body).WithMany(p => p.Measures)
                .HasForeignKey(d => d.BodyId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_measure_bodyPart");

            entity.HasOne(d => d.User).WithMany(p => p.Measures)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_measure_user");
        });

        modelBuilder.Entity<Nutrition>(entity =>
        {
            entity.ToTable("nutrition");

            entity.Property(e => e.NutritionId).HasColumnName("nutritionId");
            entity.Property(e => e.CreationDate)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("creationDate");
            entity.Property(e => e.ExpirationDate)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("expirationDate");
            entity.Property(e => e.MealId).HasColumnName("mealId");
            entity.Property(e => e.TotDailyCalories).HasColumnName("totDailyCalories");
            entity.Property(e => e.TypeNutritionId).HasColumnName("typeNutritionId");
            entity.Property(e => e.UserId).HasColumnName("userId");

            entity.HasOne(d => d.TypeNutrition).WithMany(p => p.Nutritions)
                .HasForeignKey(d => d.TypeNutritionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_nutrition_typeNutrition");

            entity.HasOne(d => d.User).WithMany(p => p.Nutritions)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_nutrition_user");
        });

        modelBuilder.Entity<NutritionMeal>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("nutritionMeal");

            entity.HasIndex(e => e.MealId, "IX_nutritionMeal_mealId");

            entity.HasIndex(e => e.NutritionId, "IX_nutritionMeal_nutritionId");

            entity.Property(e => e.MealId).HasColumnName("mealId");
            entity.Property(e => e.NutritionId).HasColumnName("nutritionId");

            entity.HasOne(d => d.Meal).WithMany()
                .HasForeignKey(d => d.MealId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_nutritionMeal_meal");

            entity.HasOne(d => d.Nutrition).WithMany()
                .HasForeignKey(d => d.NutritionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_nutritionMeal_nutrition");
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.ToTable("order");

            entity.HasIndex(e => e.PaymentTypeId, "IX_order_paymentTypeId");

            entity.HasIndex(e => e.ProductId, "IX_order_productId");

            entity.HasIndex(e => e.UserId, "IX_order_userId");

            entity.Property(e => e.OrderId).HasColumnName("orderId");
            entity.Property(e => e.Amount)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("amount");
            entity.Property(e => e.PaymentDate)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("paymentDate");
            entity.Property(e => e.PaymentTypeId).HasColumnName("paymentTypeId");
            entity.Property(e => e.ProductId).HasColumnName("productId");
            entity.Property(e => e.UserId).HasColumnName("userId");

            entity.HasOne(d => d.PaymentType).WithMany(p => p.Orders)
                .HasForeignKey(d => d.PaymentTypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_order_paymentType");

            entity.HasOne(d => d.Product).WithMany(p => p.Orders)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_order_product");

            entity.HasOne(d => d.User).WithMany(p => p.Orders)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_order_user");
        });

        modelBuilder.Entity<PaymentType>(entity =>
        {
            entity.ToTable("paymentType");

            entity.Property(e => e.PaymentTypeId).HasColumnName("paymentTypeId");
            entity.Property(e => e.PaymentTypeName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("paymentTypeName");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.ToTable("product");

            entity.HasIndex(e => e.TypePlanId, "IX_product_typePlanId");

            entity.Property(e => e.ProductId).HasColumnName("productId");
            entity.Property(e => e.Description)
                .IsUnicode(false)
                .HasColumnName("description");
            entity.Property(e => e.ExpirationDate)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("expirationDate");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("name");
            entity.Property(e => e.Price)
                .HasColumnType("decimal(5, 2)")
                .HasColumnName("price");
            entity.Property(e => e.TypePlanId).HasColumnName("typePlanId");

            entity.HasOne(d => d.TypePlan).WithMany(p => p.Products)
                .HasForeignKey(d => d.TypePlanId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_product_typePlan");
        });

        modelBuilder.Entity<Question>(entity =>
        {
            entity.ToTable("question");

            entity.Property(e => e.QuestionId).HasColumnName("questionId");
            entity.Property(e => e.QuestionString)
                .HasMaxLength(250)
                .IsUnicode(false)
                .HasColumnName("questionString");
        });

        modelBuilder.Entity<Quiz>(entity =>
        {
            entity.ToTable("quiz");

            entity.HasIndex(e => e.InputTypeId, "IX_quiz_inputTypeId");

            entity.HasIndex(e => e.QuestionId, "IX_quiz_questionId");

            entity.Property(e => e.QuizId).HasColumnName("quizId");
            entity.Property(e => e.Input).HasColumnName("input");
            entity.Property(e => e.InputTypeId).HasColumnName("inputTypeId");
            entity.Property(e => e.QuestionId).HasColumnName("questionId");
            entity.Property(e => e.SingleResponse).HasColumnName("singleResponse");

            entity.HasOne(d => d.InputType).WithMany(p => p.Quizzes)
                .HasForeignKey(d => d.InputTypeId)
                .HasConstraintName("FK_quiz_inputType");

            entity.HasOne(d => d.Question).WithMany(p => p.Quizzes)
                .HasForeignKey(d => d.QuestionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_quiz_question");
        });

        modelBuilder.Entity<ResponseQuiz>(entity =>
        {
            entity.HasKey(e => e.ResponseId);

            entity.ToTable("responseQuiz");

            entity.HasIndex(e => e.AnswerId, "IX_responseQuiz_answerId");

            entity.HasIndex(e => e.UserId, "IX_responseQuiz_userId");

            entity.Property(e => e.ResponseId).HasColumnName("responseId");
            entity.Property(e => e.AnswerId).HasColumnName("answerId");
            entity.Property(e => e.UserId).HasColumnName("userId");

            entity.HasOne(d => d.Answer).WithMany(p => p.ResponseQuizzes)
                .HasForeignKey(d => d.AnswerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_responseQuiz_answer");

            entity.HasOne(d => d.User).WithMany(p => p.ResponseQuizzes)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_responseQuiz_user");
        });

        modelBuilder.Entity<RoleUser>(entity =>
        {
            entity.HasKey(e => e.RoleId);

            entity.ToTable("roleUser");

            entity.Property(e => e.RoleId).HasColumnName("roleId");
            entity.Property(e => e.RoleName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("roleName");
        });

        modelBuilder.Entity<Training>(entity =>
        {
            entity.ToTable("training");

            entity.HasIndex(e => e.LevelId, "IX_training_levelId");

            entity.HasIndex(e => e.TypeId, "IX_training_typeId");

            entity.Property(e => e.TrainingId).HasColumnName("trainingId");
            entity.Property(e => e.CreationDate)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasDefaultValueSql("(getdate())")
                .HasColumnName("creationDate");
            entity.Property(e => e.Duration).HasColumnName("duration");
            entity.Property(e => e.EndDate)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("endDate");
            entity.Property(e => e.LevelId).HasColumnName("levelId");
            entity.Property(e => e.TypeId).HasColumnName("typeId");
            entity.Property(e => e.UserId).HasColumnName("userId");

            entity.HasOne(d => d.Level).WithMany(p => p.Training)
                .HasForeignKey(d => d.LevelId)
                .HasConstraintName("FK_training_levelTraining");

            entity.HasOne(d => d.Type).WithMany(p => p.Training)
                .HasForeignKey(d => d.TypeId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_training_typeTrainig");
        });

        modelBuilder.Entity<TypeNutrition>(entity =>
        {
            entity.ToTable("typeNutrition");

            entity.Property(e => e.TypeNutritionId).HasColumnName("typeNutritionId");
            entity.Property(e => e.TypeNutritionName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("typeNutritionName");
        });

        modelBuilder.Entity<TypePlan>(entity =>
        {
            entity.HasKey(e => e.TypePlaneId);

            entity.ToTable("typePlan");

            entity.Property(e => e.TypePlaneId).HasColumnName("typePlaneId");
            entity.Property(e => e.TypePlaneName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("typePlaneName");
        });

        modelBuilder.Entity<TypeTrainig>(entity =>
        {
            entity.HasKey(e => e.TypeId);

            entity.ToTable("typeTrainig");

            entity.Property(e => e.TypeId).HasColumnName("typeId");
            entity.Property(e => e.TypeName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("typeName");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("user");

            entity.HasIndex(e => e.RoleId, "IX_user_roleId");

            entity.Property(e => e.UserId).HasColumnName("userId");
            entity.Property(e => e.Address)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("address");
            entity.Property(e => e.BirthDate)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("birthDate");
            entity.Property(e => e.City)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("city");
            entity.Property(e => e.Country)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("country");
            entity.Property(e => e.Email)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("email");
            entity.Property(e => e.FirstName)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("firstName");
            entity.Property(e => e.ImageProfile)
                .IsUnicode(false)
                .HasColumnName("imageProfile");
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("password");
            entity.Property(e => e.Phone)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("phone");
            entity.Property(e => e.Province)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("province");
            entity.Property(e => e.PtId).HasColumnName("ptId");
            entity.Property(e => e.RoleId)
                .HasDefaultValue(1)
                .HasColumnName("roleId");
            entity.Property(e => e.Surname)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("surname");
            entity.Property(e => e.ZipCode).HasColumnName("zipCode");

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK_user_roleUser");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
